==============
Milestone 2
JOOS Benchmark
==============

Introduction
#############
Matthieu Dubet
Group K
2 October 2011
COMP 520 McGill University

Instructions
#############

A Makefile is available :

To compile with joosa- : make
To compile with javac : make java

To run with the example input in1 : make run


What is it
##########

It's a little sudoku solver, which use abstract class to provide several resolution algorithms (I have only implemented one though..)
The description of a grid is cumbersome, you should see in1 as an example.
The output is the completed grid.
The code is ugly, which is more or less on purpose, it's a benchmark :)
