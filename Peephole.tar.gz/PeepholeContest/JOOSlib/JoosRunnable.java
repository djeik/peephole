package joos.lib;

public abstract class JoosRunnable implements Runnable {
  public JoosRunnable() {};
  public abstract void run();
}
